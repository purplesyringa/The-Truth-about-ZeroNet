function save() {
	// We can omit function() {} because callback is optional
	writeFile("notepad.txt", document.getElementById("textarea").value, function() {});
}

window.addEventListener("load", function() {
	readFile("notepad.txt", function(content) {
		content = content || ""; // Parse null and undefined as empty string

		document.getElementById("save").disabled = false;
		document.getElementById("textarea").value = content;
	});
});