window.zeroFrame = new ZeroFrame();

window.addEventListener("load", function() {
	var questionId = parseInt(location.search.match(/^\?(\d+)/)[1]);

	getQuestion(questionId, function(question) {
		document.getElementById("question_name").textContent = question.question;


		var node = document.getElementById("answers");

		var answerInputs = [];
		var answers = question.answers.split("\n");

		var totalAnswers = 0;
		if(question.otherAnswers) {
			for(var i in question.otherAnswers) {
				if(!question.otherAnswers.hasOwnProperty(i)) {
					continue;
				}

				totalAnswers += question.otherAnswers[i];
			}
		}

		for(var i = 0; i < answers.length; i++) {
			(function(i) {
				var answer = answers[i];

				var inputNode = document.createElement("input");
				inputNode.type = "radio";
				inputNode.name = "answer";
				inputNode.id = "answer" + i;
				answerInputs.push(inputNode);
				node.appendChild(inputNode);

				var labelNode = document.createElement("label");
				labelNode.setAttribute("for", "answer" + i);
				labelNode.textContent = answer;
				node.appendChild(labelNode);

				var brNode = document.createElement("br");
				node.appendChild(brNode);

				if(question.answered != -1) {
					var number = question.otherAnswers[i] || 0;
					var percent = totalAnswers == 0 ? 0 : Math.round(number / totalAnswers * 100);

					inputNode.disabled = true;
					labelNode.innerHTML = "<b>(" + percent + "%)</b> " + labelNode.innerHTML;
				}
			})(i);
		}

		if(question.answered != -1) {
			answerInputs[question.answered].checked = true;
		}


		document.getElementById("submit").onclick = function() {
			if(question.answered != -1) {
				return;
			}

			var checked = null;
			for(var i = 0; i < answerInputs.length; i++) {
				if(answerInputs[i].checked) {
					checked = i;
					break;
				}
			}
			if(checked === null) {
				return;
			}

			addAnswer(questionId, checked, function() {
				location.href = "view.html?" + questionId;
			});
		};
	});
});