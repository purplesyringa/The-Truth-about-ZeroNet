function editUserData(handler, callback) {
	authAsZeroID(function(user) {
		// User rejected to authorizate
		if(!user) {
			callback(false);
			return;
		}
		
		readFile("data/users/" + user.address + "/data.json", function(content) {
			content = content || "";
			
			// Parse JSON
			try {
				content = JSON.parse(content);
			} catch(e) {
				content = {
					questions: [],
					answers: {},
					next_question_id: 0
				};
			}

			handler(content);

			content = JSON.stringify(content);
			
			writeFile("data/users/" + user.address + "/data.json", content, function() {
				zeroFrame.cmd("sitePublish", {
					inner_path: "data/users/" + user.address + "/content.json"
				}, callback);
			});
		});
	});
}

function addQuestion(question, answers, callback) {
	var id;
	editUserData(function(content) {
		id = content.next_question_id;

		content.questions.push({
			id: content.next_question_id++,
			question: question,
			answers: answers.join("\n"),
			date_added: Math.floor(Date.now() / 1000)
		});
	}, function() {
		callback(id);
	});
}

function addAnswer(questionId, answerId, callback) {
	editUserData(function(content) {
		content.answers[questionId] = answerId;
	}, callback);
}

function getQuestionList(sort, callback) {
	if(sort == "popular") {
		zeroFrame.cmd("dbQuery", ["SELECT questions.*, CASE WHEN answers.answer_count IS NULL THEN 0 ELSE answers.answer_count END AS answer_count FROM questions LEFT JOIN (SELECT question_id, COUNT(*) as answer_count FROM answers GROUP BY question_id) AS answers ON (answers.question_id = questions.id) ORDER BY answers.answer_count DESC, questions.date_added DESC LIMIT 0, 10"], callback);
	} else if(sort == "latest") {
		zeroFrame.cmd("dbQuery", ["SELECT * FROM questions ORDER BY date_added DESC LIMIT 0, 10"], callback);
	}
}

function getQuestion(id, callback) {
	zeroFrame.cmd("dbQuery", ["SELECT * FROM questions WHERE id = " + id], function(questions) {
		zeroFrame.cmd("siteInfo", [], function(siteInfo) {
			if(siteInfo.cert_user_id) { // User logged in
				zeroFrame.cmd("dbQuery", ["SELECT answers.*, json.* FROM answers, json WHERE json.directory = \"users/" + siteInfo.auth_address + "\" AND answers.json_id = json.json_id AND answers.question_id = " + id], function(answer) {
					if(answer.length) {
						questions[0].answered = answer[0].answer_id;

						getAnswers(id, function(answers) {
							questions[0].otherAnswers = answers;
							callback(questions[0]);
						});
					} else {
						questions[0].answered = -1;
						callback(questions[0]);
					}
				});
			} else {
				questions[0].answered = -1;
				callback(questions[0]);
			}
		});
	});
}

function getAnswers(id, callback) {
	zeroFrame.cmd("dbQuery", ["SELECT answer_id, COUNT(*) as answer_count FROM answers WHERE question_id = " + id + " GROUP BY answer_id"], function(answers) {
		var result = {};
		for(var i = 0; i < answers.length; i++) {
			result[answers[i].answer_id] = answers[i].answer_count;
		}
		callback(result);
	});
}