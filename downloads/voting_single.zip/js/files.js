function readFile(file, callback) {
	zeroFrame.cmd("fileGet", [file, false], callback);
}

function writeFile(file, content, callback) {
	zeroFrame.cmd("fileWrite", [file, base64Encode(content)], callback);
}

function base64Encode(content) {
	content = encodeURIComponent(content); // Split to bytes in % notation
	content = unescape(content); // Join % notation as bytes (not as chars)
	return btoa(content);
}