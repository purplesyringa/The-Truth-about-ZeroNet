function authAsZeroID(callback) {
	zeroFrame.cmd("siteInfo", [], function(siteInfo) {
		// If logged in, return object with username and public key (address)
		if(siteInfo.cert_user_id) {
			callback({
				user: siteInfo.cert_user_id,
				address: siteInfo.auth_address
			});
			
			return;
		}
		
		// Open authorization window and allow zeroid.bit
		zeroFrame.cmd("certSelect", {
			accepted_domains: ["zeroid.bit"]
		}, function() {
			zeroFrame.cmd("siteInfo", [], function(siteInfo) {
				// If logged in, return object with username and public key (address),
				// else return false
				if(siteInfo.cert_user_id) {
					callback({
						user: siteInfo.cert_user_id,
						address: siteInfo.auth_address
					});
				} else {
					callback(false);
				}
			});
		});
	});
}