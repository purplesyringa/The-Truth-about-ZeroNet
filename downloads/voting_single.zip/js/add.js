window.zeroFrame = new ZeroFrame();

window.addEventListener("load", function() {
	document.getElementById("add").onclick = function() {
		var questionName = document.getElementById("question_name").value;
		if(!questionName) {
			return;
		}


		var answerNodes = document.querySelectorAll("#answers input[type=text]")
		var answers = [];
		for(var i = 0; i < answerNodes.length; i++) {
			if(answerNodes[i].value) {
				answers.push(answerNodes[i].value);
			}
		}
		if(answers.length < 2) {
			return;
		}

		addQuestion(questionName, answers, function(id) {
			location.href = "view.html?" + id;
		});
	};
});