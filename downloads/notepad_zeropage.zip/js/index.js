var zeroFrame = new ZeroFrame();
var zeroPage = new ZeroPage(zeroFrame);

function readFile(file) {
	return zeroPage.cmd("fileGet", [file, false]);
}

function writeFile(file, content) {
	return zeroPage.cmd("fileWrite", [file, base64Encode(content)]);
}

function writeBinaryFile(file, content, callback) {
	return zeroPage.cmd("fileWrite", [file, btoa(content)]);
}

function base64Encode(content) {
	content = encodeURIComponent(content); // Split to bytes in % notation
	content = unescape(content); // Join % notation as bytes (not as chars)
	return btoa(content);
}