function save() {
	writeFile("notepad.txt", document.getElementById("textarea").value);
}

window.addEventListener("load", function() {
	readFile("notepad.txt")
		.then(function(content) {
			content = content || ""; // Parse null and undefined as empty string

			document.getElementById("save").disabled = false;
			document.getElementById("textarea").value = content;
		});
});