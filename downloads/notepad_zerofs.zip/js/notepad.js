function save() {
	writeFile("notepad.txt", document.getElementById("textarea").value);
}

window.addEventListener("load", function() {
	readFile("notepad.txt")
		.catch(function() { return ""; })
		.then(function(content) {
			document.getElementById("save").disabled = false;
			document.getElementById("textarea").value = content;
		});
});