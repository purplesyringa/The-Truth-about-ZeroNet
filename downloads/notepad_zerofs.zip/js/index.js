var zeroFrame = new ZeroFrame();
var zeroPage = new ZeroPage(zeroFrame);
var zeroFS = new ZeroFS(zeroPage);

function readFile(file) {
	return zeroFS.readFile(file);
}

function writeFile(file, content) {
	return zeroFS.writeFile(file, content);
}

function writeBinaryFile(file, content, callback) {
	return zeroFS.writeFile(file, content, true);
}