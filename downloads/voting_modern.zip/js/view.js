window.zeroFrame = new ZeroFrame();
window.zeroPage = new ZeroPage(zeroFrame);
window.zeroFS = new ZeroFS(zeroPage);
window.zeroAuth = new ZeroAuth(zeroPage);

window.addEventListener("load", function() {
	let questionId = parseInt(location.search.match(/^\?(\d+)/)[1]);

	return getQuestion(questionId)
		.then(question => {
			document.getElementById("question_name").textContent = question.question;


			let node = document.getElementById("answers");

			let answerInputs = [];
			let answers = question.answers.split("\n");

			let totalAnswers = 0;
			if(question.otherAnswers) {
				totalAnswers = Object.values(question.otherAnswers).reduce((a, b) => a + b);
			}

			answers.forEach((answer, i) => {
				let inputNode = document.createElement("input");
				inputNode.type = "radio";
				inputNode.name = "answer";
				inputNode.id = "answer" + i;
				answerInputs.push(inputNode);
				node.appendChild(inputNode);

				let labelNode = document.createElement("label");
				labelNode.setAttribute("for", "answer" + i);
				labelNode.textContent = answer;
				node.appendChild(labelNode);

				let brNode = document.createElement("br");
				node.appendChild(brNode);

				if(question.answered != -1) {
					let number = question.otherAnswers[i] || 0;
					let percent = totalAnswers == 0 ? 0 : Math.round(number / totalAnswers * 100);

					inputNode.disabled = true;
					labelNode.innerHTML = "<b>(" + percent + "%)</b> " + labelNode.innerHTML;
				}
			});

			if(question.answered != -1) {
				answerInputs[question.answered].checked = true;
			}


			document.getElementById("submit").onclick = () => {
				if(question.answered != -1) {
					return;
				}

				let checked = answerInputs.indexOf(answerInputs.find(input => input.checked));
				if(checked == -1) {
					return;
				}

				addAnswer(questionId, checked)
					.then(() => {
						location.href = "view.html?" + questionId;
					});
			};
		});
});