window.zeroFrame = new ZeroFrame();
window.zeroPage = new ZeroPage(zeroFrame);
window.zeroFS = new ZeroFS(zeroPage);
window.zeroAuth = new ZeroAuth(zeroPage);

window.addEventListener("load", function() {
	document.getElementById("add").onclick = function() {
		let questionName = document.getElementById("question_name").value;
		if(!questionName) {
			return;
		}


		let answerNodes = document.querySelectorAll("#answers input[type=text]")
		let answers = Array.prototype.slice.call(answerNodes).map(node => node.value).filter(value => value.length);
		if(answers.length < 2) {
			return;
		}

		addQuestion(questionName, answers)
			.then(id => {
				location.href = "view.html?" + id;
			});
	};
});