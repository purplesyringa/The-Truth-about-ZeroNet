window.zeroFrame = new ZeroFrame();
window.zeroPage = new ZeroPage(zeroFrame);
window.zeroFS = new ZeroFS(zeroPage);
window.zeroAuth = new ZeroAuth(zeroPage);

function showQuestionList(type) {
	getQuestionList(type)
		.then(questions => {
			var node = document.getElementById(type + "_questions");

			questions.forEach(question => {
				let questionNode = document.createElement("a");
				questionNode.href = "view.html?" + question.id;
				questionNode.className = "question-list-item";
				questionNode.textContent = question.question;
				node.appendChild(questionNode);
			});
		});
}

window.addEventListener("load", function() {
	showQuestionList("popular");
	showQuestionList("latest");
});