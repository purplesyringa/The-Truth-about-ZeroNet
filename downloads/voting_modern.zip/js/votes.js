function editUserData(handler) {
	return zeroAuth.requestAuth()
		.then(user => {
			return zeroFS.readFile("data/users/" + user.address + "/data.json")
				.catch(() => "")
				.then(content => {
					// Parse JSON
					try {
						content = JSON.parse(content);
					} catch(e) {
						content = {
							questions: [],
							answers: {},
							next_question_id: 0
						};
					}

					handler(content);

					content = JSON.stringify(content);
					
					return zeroFS.writeFile("data/users/" + user.address + "/data.json", content);
				})
				.then(() => {
					return zeroPage.cmd("sitePublish", {
						inner_path: "data/users/" + user.address + "/content.json"
					});
				});
		})
		.catch(() => false);
}

function addQuestion(question, answers) {
	let id;
	return editUserData(content => {
		id = content.next_question_id;

		content.questions.push({
			id: content.next_question_id++,
			question: question,
			answers: answers.join("\n"),
			date_added: Math.floor(Date.now() / 1000)
		});
	})
		.then(() => id);
}

function addAnswer(questionId, answerId) {
	return editUserData(content => {
		content.answers[questionId] = answerId;
	});
}

function getQuestionList(sort) {
	if(sort == "popular") {
		return zeroPage.cmd("dbQuery", ["SELECT questions.*, CASE WHEN answers.answer_count IS NULL THEN 0 ELSE answers.answer_count END AS answer_count FROM questions LEFT JOIN (SELECT question_id, COUNT(*) as answer_count FROM answers GROUP BY question_id) AS answers ON (answers.question_id = questions.id) ORDER BY answers.answer_count DESC, questions.date_added DESC LIMIT 0, 10"]);
	} else if(sort == "latest") {
		return zeroPage.cmd("dbQuery", ["SELECT * FROM questions ORDER BY date_added DESC LIMIT 0, 10"]);
	}
}

function getQuestion(id) {
	let questions;

	return zeroPage.cmd("dbQuery", ["SELECT * FROM questions WHERE id = " + id])
		.then(q => {
			questions = q;

			return zeroPage.getSiteInfo();
		})
		.then(siteInfo => {
			if(siteInfo.cert_user_id) { // User logged in
				return zeroPage.cmd("dbQuery", ["SELECT answers.*, json.* FROM answers, json WHERE json.directory = \"users/" + siteInfo.auth_address + "\" AND answers.json_id = json.json_id AND answers.question_id = " + id])
					.then(answer => {
						questions[0].answered = answer.length ? answer[0].answer_id : -1;

						let promise = Promise.resolve();

						if(answer.length) {
							promise = getAnswers(id)
								.then(answers => {
									questions[0].otherAnswers = answers;
								});
						}

						return promise.then(() => questions[0]);
					});
			} else {
				questions[0].answered = -1;
				return questions[0];
			}
		});
}

function getAnswers(id) {
	return zeroPage.cmd("dbQuery", ["SELECT answer_id, COUNT(*) as answer_count FROM answers WHERE question_id = " + id + " GROUP BY answer_id"])
		.then(answers => {
			let result = {};
			answers.forEach(answer => {
				result[answer.answer_id] = answer.answer_count;
			});
			return result;
		});
}