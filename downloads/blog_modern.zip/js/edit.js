window.zeroFrame = new ZeroFrame();
window.zeroPage = new ZeroPage(zeroFrame);
window.zeroFS = new ZeroFS(zeroPage);

window.postId = parseInt(location.search.match(/^\?(\d+)/)[1]);

function publish() {
	let title = document.getElementById("title").value;
	let content = document.getElementById("content").value;

	updatePost(postId, {
		title: title,
		content: content
	})
		.then(() => {
			location.href = "post.html?" + postId;
		});
}

window.addEventListener("load", function() {
	zeroPage.getSiteInfo()
		.then(info => {
			if(!info.privatekey) {
				location.href = "index.html";
			}

			return getPost(postId);
		})
		.then(post => {
			document.getElementById("title").value = post.title;
			document.getElementById("content").value = post.content;
		});
});