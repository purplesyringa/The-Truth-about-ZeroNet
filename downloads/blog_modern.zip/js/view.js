window.zeroFrame = new ZeroFrame();
window.zeroPage = new ZeroPage(zeroFrame);
window.zeroFS = new ZeroFS(zeroPage);

window.postId = parseInt(location.search.match(/^\?(\d+)/)[1]);

window.addEventListener("load", () => {
	zeroPage.getSiteInfo()
		.then(info => {
			if(!info.privatekey) {
				location.href = "index.html";
			}

			return getPost(postId);
		})
		.then(post => {
			document.getElementById("title").innerHTML = post.title;
			document.getElementById("content").innerHTML = post.content;
		});
});