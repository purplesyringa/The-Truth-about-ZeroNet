function loadPosts() {
	zeroPage.cmd("dbQuery", ["SELECT * FROM posts ORDER BY id DESC"])
		.then(function(posts) {
			var node = document.getElementById("posts");
			node.innerHTML = "";

			for(var i = 0; i < posts.length; i++) {
				(function(i) {
					var post = posts[i];

					var postNode = document.createElement("div");
					postNode.className = "post";

					var link = document.createElement("a");
					link.href = "post.html?" + post.id;
					link.innerHTML = post.title;
					postNode.appendChild(link);

					if(isAdmin) {
						var edit = document.createElement("span");
						edit.className = "post-edit";
						edit.innerHTML = " Edit";
						edit.onclick = function(e) {
							location.href = "edit.html?" + post.id;

							e.preventDefault();
							e.stopPropagation();
						};
						link.appendChild(edit);
					}

					var content = document.createElement("div");
					content.innerHTML = post.content.length > 100 ? post.content.substr(0, 100) + "..." : post.content;
					postNode.appendChild(content);

					node.appendChild(postNode);
				})(i);
			}
		});
}

function addPost() {
	var id;

	return zeroFS.readFile("data/admin/data.json")
		.catch(function() { return ""; })
		.then(function(content) {
			// Parse JSON
			try {
				content = JSON.parse(content);
			} catch(e) {
				content = {
					posts: [],
					next_post_id: 0
				};
			}

			id = content.next_post_id;

			content.posts.push({
				id: id, // Use next_post_id and then increment it
				title: "New post",
				content: "New post content"
			});

			content.next_post_id++;

			content = JSON.stringify(content, null, 4); // Make content string

			return zeroFS.writeFile("data/admin/data.json", content);
		})
		.then(function() {
			return id;
		});
}

function getPost(id) {
	return zeroPage.cmd("dbQuery", ["SELECT * FROM posts WHERE id = " + id])
		.then(function(posts) {
			return posts[0];
		});
}

function updatePost(id, post) {
	return zeroFS.readFile("data/admin/data.json")
		.catch(function() { return ""; })
		.then(function(content) {
			// Parse JSON
			try {
				content = JSON.parse(content);
			} catch(e) {
				content = {
					posts: [],
					next_post_id: 0
				};
			}

			for(var i = 0; i < content.posts.length; i++) {
				if(content.posts[i].id == id) {
					Object.assign(content.posts[i], post);
					break;
				}
			}

			content = JSON.stringify(content, null, 4); // Make content string

			return zeroFS.writeFile("data/admin/data.json", content);
		})
		.then(function() {
			return zeroPage.publish();
		});
}