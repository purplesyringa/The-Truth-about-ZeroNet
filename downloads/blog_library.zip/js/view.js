window.zeroFrame = new ZeroFrame();
window.zeroPage = new ZeroPage(zeroFrame);
window.zeroFS = new ZeroFS(zeroPage);

window.postId = parseInt(location.search.match(/^\?(\d+)/)[1]);

window.addEventListener("load", function() {
	zeroPage.getSiteInfo()
		.then(function(info) {
			if(!info.privatekey) {
				location.href = "index.html";
			}

			return getPost(postId);
		})
		.then(function(post) {
			document.getElementById("title").innerHTML = post.title;
			document.getElementById("content").innerHTML = post.content;
		});
});