window.zeroFrame = new ZeroFrame();
window.zeroPage = new ZeroPage(zeroFrame);
window.zeroFS = new ZeroFS(zeroPage);

window.addEventListener("load", function() {
	zeroPage.getSiteInfo()
		.then(function(info) {
			window.isAdmin = !!info.privatekey;

			if(isAdmin) {
				var postAdd = document.getElementById("post_add");
				postAdd.style.display = "block";
				postAdd.onclick = function() {
					addPost()
						.then(function(id) {
							location.href = "edit.html?" + id;
						});
				};
			}

			loadPosts();
		});
});