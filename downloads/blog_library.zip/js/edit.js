window.zeroFrame = new ZeroFrame();
window.zeroPage = new ZeroPage(zeroFrame);
window.zeroFS = new ZeroFS(zeroPage);

window.postId = parseInt(location.search.match(/^\?(\d+)/)[1]);

function publish() {
	var title = document.getElementById("title").value;
	var content = document.getElementById("content").value;

	updatePost(postId, {
		title: title,
		content: content
	})
		.then(function() {
			location.href = "post.html?" + postId;
		});
}

window.addEventListener("load", function() {
	zeroPage.getSiteInfo()
		.then(function(info) {
			if(!info.privatekey) {
				location.href = "index.html";
			}

			return getPost(postId);
		})
		.then(function(post) {
			document.getElementById("title").value = post.title;
			document.getElementById("content").value = post.content;
		});
});