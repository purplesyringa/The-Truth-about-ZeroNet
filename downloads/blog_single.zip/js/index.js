window.zeroFrame = new ZeroFrame();

window.addEventListener("load", function() {
	zeroFrame.cmd("siteInfo", [], function(info) {
		window.isAdmin = !!info.privatekey;

		if(isAdmin) {
			var postAdd = document.getElementById("post_add");
			postAdd.style.display = "block";
			postAdd.onclick = function() {
				addPost(function(id) {
					location.href = "edit.html?" + id;
				});
			};
		}

		loadPosts();
	});
});