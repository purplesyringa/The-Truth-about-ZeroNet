window.zeroFrame = new ZeroFrame();

window.postId = parseInt(location.search.match(/^\?(\d+)/)[1]);

window.addEventListener("load", function() {
	zeroFrame.cmd("siteInfo", [], function(info) {
		if(!info.privatekey) {
			location.href = "index.html";
		}

		getPost(postId, function(post) {
			document.getElementById("title").innerHTML = post.title;
			document.getElementById("content").innerHTML = post.content;
		});
	});
});