window.zeroFrame = new ZeroFrame();

window.postId = parseInt(location.search.match(/^\?(\d+)/)[1]);

function publish() {
	var title = document.getElementById("title").value;
	var content = document.getElementById("content").value;

	updatePost(postId, {
		title: title,
		content: content
	}, function() {
		location.href = "post.html?" + postId;
	});
}

window.addEventListener("load", function() {
	zeroFrame.cmd("siteInfo", [], function(info) {
		if(!info.privatekey) {
			location.href = "index.html";
		}

		getPost(postId, function(post) {
			document.getElementById("title").value = post.title;
			document.getElementById("content").value = post.content;
		});
	});
});