window.zeroFrame = new ZeroFrame();
window.zeroPage = new ZeroPage(zeroFrame);
window.zeroFS = new ZeroFS(zeroPage);
window.zeroAuth = new ZeroAuth(zeroPage);

function showQuestionList(type) {
	getQuestionList(type)
		.then(function(questions) {
			var node = document.getElementById(type + "_questions");

			for(var i = 0; i < questions.length; i++) {
				(function(i) {
					var question = questions[i];

					var questionNode = document.createElement("a");
					questionNode.href = "view.html?" + question.id;
					questionNode.className = "question-list-item";
					questionNode.textContent = question.question;
					node.appendChild(questionNode);
				})(i);
			}
		});
}

window.addEventListener("load", function() {
	showQuestionList("popular");
	showQuestionList("latest");
});